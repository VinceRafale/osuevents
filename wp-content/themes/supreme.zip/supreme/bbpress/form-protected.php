<?php

/**
 * Password Protected
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

	<div class="bbp-form" id="bbp-protected">
		<h3><?php _e( 'Protected', 'bbpress' ); ?></h3>
		<?php echo get_the_password_form(); ?>
	</div>
